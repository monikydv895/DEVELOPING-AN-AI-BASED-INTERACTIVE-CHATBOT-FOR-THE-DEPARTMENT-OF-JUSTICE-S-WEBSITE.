document.addEventListener("DOMContentLoaded", function () {
    const chatbotContainer = document.getElementById("chatbot-container");
    const chatbotIcon = document.getElementById("chatbot-icon");
    const closeButton = document.getElementById("close-btn");
    const sendBtn = document.getElementById("send-btn");
    const chatbotInput = document.getElementById("chatbot-input");
    const chatbotMessages = document.getElementById("chatbot-messages");
    const micBtn = document.getElementById("mic-btn");
    const stopBtn = document.getElementById("stop-btn");

    let selectedLanguage = null;
    let recognition = null;
    let firDataset = {};
    let lawyerDataset = {};
    let ccDataset = [];
    let lacDataset = [];
    let crlMiscDataset = [];
    let mvcDataset = [];

    // --- Load Datasets ---
     fetch("fir_case_dataset.json").then(res => res.json()).then(data => { firDataset = data; });
    fetch("lawyer_details.json").then(res => res.json()).then(data => { lawyerDataset = data; console.log("Loaded lawyerDataset:", lawyerDataset); });
    fetch("c.c.json").then(res => res.json()).then(data => { ccDataset = data; });
    fetch("lac.json").then(res => res.json()).then(data => { lacDataset = data; });
    fetch("crl_misc.json").then(res => res.json()).then(data => { crlMiscDataset = data; });
    fetch("mvc.json").then(res => res.json()).then(data => { mvcDataset = data; });

    chatbotIcon.addEventListener("click", function () {
        chatbotContainer.style.display = "flex";
        chatbotIcon.style.display = "none";
        displayLanguageOptions();
    });

    closeButton.addEventListener("click", function () {
        chatbotContainer.style.display = "none";
        chatbotIcon.style.display = "block";
    });

    sendBtn.addEventListener("click", sendMessage);
    chatbotInput.addEventListener("keypress", function (e) {
        if (e.key === "Enter") sendMessage();
    });

    function appendMessage(sender, message) {
        const messageElement = document.createElement("div");
        messageElement.classList.add("message", sender);
        messageElement.innerHTML = message.replace(/\n/g, '<br>'); // Basic formatting
        chatbotMessages.appendChild(messageElement);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
        if (sender === "bot" && "speechSynthesis" in window && selectedLanguage) {
            speakMessage(message);
        }
    }

    function displayLanguageOptions() {
        chatbotMessages.innerHTML = '<div class="message bot">Choose a preferred language:</div>';
        [
            { code: "en-US", name: "English" },
            { code: "kn-IN", name: "Kannada" },
            { code: "hi-IN", name: "Hindi" },
            { code: "te-IN", name: "Telugu" },
            { code: "mr-IN", name: "Marathi" }
        ].forEach(lang => {
            const button = document.createElement("button");
            button.classList.add("lang-button");
            button.textContent = lang.name;
            button.onclick = () => setLanguage(lang.code);
            chatbotMessages.appendChild(button);
        });
    }

    function setLanguage(lang) {
        selectedLanguage = lang;
        appendMessage("bot", `Language set to: ${lang}`);
        appendMessage("bot", "Now you can start chatting! Here are some things you can try asking:");
    }

    function sendMessage() {
        const userMessage = chatbotInput.value.trim();
        if (!selectedLanguage) {
            appendMessage("bot", "Please select a language first.");
            return;
        }
        if (userMessage) {
            appendMessage("user", userMessage);
            chatbotInput.value = "";
            getBotResponse(userMessage);
        }
    }

    // --- Hybrid Algorithm 1: Improved Intent Recognition (Rule-Based + Basic Statistical) ---
    function categorizeIntent(query) {
        const lowerQuery = query.toLowerCase();

        // Rule-based checks
        if (lowerQuery.includes("criminal case") || lowerQuery.includes("criminal cases")) return "display_cc";
        if (lowerQuery.includes("display crl.misc details") || lowerQuery.includes("display criminal miscellaneous case details")) return "display_crl_misc";
        if (lowerQuery.includes("display lac case") || lowerQuery.includes("display land acquisition cases")) return "display_lac";
        if (lowerQuery.includes("display mac details") || lowerQuery.includes("display motor vehicle claim details")) return "display_mvc";
        if (lowerQuery.includes("display different type of lawyer details") || lowerQuery.includes("find a lawyer")) return "display_lawyers";

        // Basic Statistical Check (Keyword Frequency - very basic example)
        const keywords = {
            "case": 1,
            "details": 1,
            "lawyer": 1,
            "criminal": 0.8,
            "land": 0.7,
            "motor": 0.6,
            "acquisition": 0.7,
            "misc": 0.5
        };

        let scores = {
            "case_info": 0,
            "lawyer_info": 0,
            "general": 0
        };

        lowerQuery.split(/\s+/).forEach(word => {
            if (keywords[word]) {
                if (lowerQuery.includes("case") || lowerQuery.includes("details")) scores["case_info"] += keywords[word];
                if (lowerQuery.includes("lawyer")) scores["lawyer_info"] += keywords[word];
            }
        });

        if (scores["case_info"] > scores["lawyer_info"] && scores["case_info"] > 0) return "search_cases";
        if (scores["lawyer_info"] > 0) return "search_lawyers";

        return "general_query"; // Default to OpenAI
    }

    // --- Hybrid Algorithm 2: Enhanced Data Retrieval (Keyword + Placeholder for Semantic) ---
    async function getBotResponse(userMessage) {
        const intent = categorizeIntent(userMessage);
        const lowerQuery = userMessage.toLowerCase();

        switch (intent) {
            case "display_cc":
                displayCaseDetails("C.C.", ccDataset, "Criminal Cases");
                break;
            case "display_crl_misc":
                displayCaseDetails("Crl. Misc", crlMiscDataset, "Criminal Miscellaneous Cases");
                break;
            case "display_lac":
                displayCaseDetails("LAC", lacDataset, "Land Acquisition Cases");
                break;
            case "display_mvc":
                displayCaseDetails("MAC", mvcDataset, "Motor Vehicle Claim Cases");
                break;
            case "display_lawyers":
                displayLawyerDetails(lowerQuery);
                break;
            case "search_cases":
                // First try keyword search
                let keywordMatches = searchDatasetsCombined(lowerQuery);
                if (keywordMatches.length > 0) {
                    displaySearchResults(keywordMatches);
                } else {

                        callOpenAI(userMessage);
                
                }
                break;
            case "search_lawyers":
                displayLawyerDetails(lowerQuery);
                break;
            case "general_query":
            default:
                callOpenAI(userMessage);
                break;
        }
    }

    function searchDatasetsCombined(query) {
        let matches = [];
        matches = matches.concat(searchDatasets(ccDataset, query));
        matches = matches.concat(searchDatasets(lacDataset, query));
        matches = matches.concat(searchDatasets(crlMiscDataset, query));
        matches = matches.concat(searchDatasets(mvcDataset, query));
        return matches;
    }

    function searchDatasets(dataset, query) {
        const lowerQuery = query.toLowerCase();
        return dataset.filter(item =>
            (item["Case Type/Case Number/Case Year"] || "").toLowerCase().includes(lowerQuery) ||
            (item["Petitioner versus Respondent"] || "").toLowerCase().includes(lowerQuery)
        );
    }

    function displayCaseDetails(caseTypePrefix, dataset, caseTypeName) {
        if (dataset.length > 0) {
            chatbotMessages.innerHTML = ""; // Clear previous messages
            dataset.slice(0, 5).forEach((caseItem, index) => {
                const card = document.createElement("div");
                card.classList.add("card");
                card.innerHTML = `
                    <h3>📚 ${caseTypeName} - Case ${index + 1}</h3>
                    <p><strong>Case:</strong> ${caseItem["Case Type/Case Number/Case Year"]}</p>
                    <p><strong>Petitioner vs Respondent:</strong> ${caseItem["Petitioner versus Respondent"]}</p>
                `;
                chatbotMessages.appendChild(card);
            });
            if (dataset.length > 5) {
                const info = document.createElement("div");
                info.classList.add("info-message");
                info.textContent = `Showing top 5 ${caseTypeName}. Search more specifically for the full list. 📄`;
                chatbotMessages.appendChild(info);
            }
        } else {
            appendMessage("bot", `No ${caseTypeName} found at the moment. 📄`);
        }
    }

    function displaySearchResults(results) {
        if (results.length > 0) {
            chatbotMessages.innerHTML = ""; // Clear previous messages
            results.slice(0, 5).forEach((item, index) => {
                const card = document.createElement("div");
                card.classList.add("card");
                card.innerHTML = `
                    <h3>📚 Found Case ${index + 1}</h3>
                    <p><strong>Case:</strong> ${item["Case Type/Case Number/Case Year"]}</p>
                    <p><strong>Petitioner vs Respondent:</strong> ${item["Petitioner versus Respondent"]}</p>
                `;
                chatbotMessages.appendChild(card);
            });
            if (results.length > 5) {
                const info = document.createElement("div");
                info.classList.add("info-message");
                info.textContent = "Showing top 5 results. Try searching more specifically. 📄";
                chatbotMessages.appendChild(info);
            }
        } else {
            appendMessage("bot", "No matching cases found. Please try a different search term. 🔍");
        }
    }

function displayLawyerDetails(query) {
        const lowerQuery = query.toLowerCase();
        if (!lawyerDataset.lawyers || !Array.isArray(lawyerDataset.lawyers)) {
            appendMessage("bot", "Lawyer data is not available at the moment. 🔍");
            return;
        }
        // If query is generic, show all lawyers
        if (lowerQuery === "lawyer details" || lowerQuery === "find a lawyer" || lowerQuery.trim() === "") {
            chatbotMessages.innerHTML = ""; // Clear previous messages
            lawyerDataset.lawyers.slice(0, 5).forEach((lawyer, index) => {
                const card = document.createElement("div");
                card.classList.add("card");
                card.innerHTML = `
                    <h3>🧑‍⚖ Lawyer ${index + 1}</h3>
                    <p><strong>Type:</strong> ${lawyer.type}</p>
                    <p><strong>Description:</strong> ${lawyer.description}</p>
                    <p><strong>Example Cases:</strong> ${lawyer.example_cases ? lawyer.example_cases.join(", ") : "N/A"}</p>
                    <p><strong>Clients:</strong> ${lawyer.clients ? lawyer.clients.join(", ") : "N/A"}</p>
                `;
                chatbotMessages.appendChild(card);
            });
            if (lawyerDataset.lawyers.length > 5) {
                const info = document.createElement("div");
                info.classList.add("info-message");
                info.textContent = "Showing top 5 lawyers. Search more specifically for more results. 📄";
                chatbotMessages.appendChild(info);
            }
        } else {
            const matchingLawyers = lawyerDataset.lawyers.filter(lawyer =>
                (lawyer.type || "").toLowerCase().includes(lowerQuery) ||
                (lawyer.description || "").toLowerCase().includes(lowerQuery)
            );

            if (matchingLawyers.length > 0) {
                chatbotMessages.innerHTML = ""; // Clear previous messages
                matchingLawyers.slice(0, 5).forEach((lawyer, index) => {
                    const card = document.createElement("div");
                    card.classList.add("card");
                    card.innerHTML = `
                        <h3>🧑‍⚖ Lawyer ${index + 1}</h3>
                        <p><strong>Type:</strong> ${lawyer.type}</p>
                        <p><strong>Description:</strong> ${lawyer.description}</p>
                        <p><strong>Example Cases:</strong> ${lawyer.example_cases ? lawyer.example_cases.join(", ") : "N/A"}</p>
                        <p><strong>Clients:</strong> ${lawyer.clients ? lawyer.clients.join(", ") : "N/A"}</p>
                    `;
                    chatbotMessages.appendChild(card);
                });
                if (matchingLawyers.length > 5) {
                    const info = document.createElement("div");
                    info.classList.add("info-message");
                    info.textContent = "Showing top 5 lawyers. Search more specifically for more results. 📄";
                    chatbotMessages.appendChild(info);
                }
            } else {
                appendMessage("bot", "No matching lawyers found. Please try a different search term or specialization. 🔍");
            }
        }
    }

    async function callOpenAI(userMessage) {
        const apiKey = "sk-Q3RfWdWgib6OcKQ9KI3C2YoxLCNE1L8_G-L3WXpevpT3BlbkFJSyfWyP5vHjPyfp_e26IbP4dXHqzjsX3o1voFqxglEA"; // Replace with your actual API key here
        const apiUrl = "https://api.openai.com/v1/chat/completions";

        try {
            const response = await fetch(apiUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${apiKey}`,
                },
                body: JSON.stringify({
                    model: "gpt-3.5-turbo",
                    messages: [
                        { role: "system", content: `You are a helpful legal assistant. Reply in ${selectedLanguage}` },
                        { role: "user", content: userMessage }
                    ],
                    max_tokens: 150,
                }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                console.error("OpenAI API Error:", errorData);
                appendMessage("bot", "Oops! There was an issue communicating with the AI. 😕");
                return;
            }

            const data = await response.json();
            if (data.choices && data.choices.length > 0) {
                appendMessage("bot", data.choices[0].message.content);
            } else {
                appendMessage("bot", "Sorry, I didn't get a clear response from the AI. 😕");
            }

        } catch (error) {
            console.error("OpenAI API Error:", error);
            appendMessage("bot", "Oops! Something went wrong. 😕");
        }
    }

    // --- Speech Recognition ---
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
        recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.continuous = false;

        micBtn.addEventListener("click", function () {
            if (!selectedLanguage) {
                appendMessage("bot", "Please select a language first.");
                return;
            }
            recognition.lang = selectedLanguage;
            recognition.start();
            micBtn.style.backgroundColor = "#b71c1c";
            stopBtn.style.display = "block";
        });

        recognition.onresult = function (event) {
            chatbotInput.value = event.results[0][0].transcript;
            sendMessage();
        };

        recognition.onend = function () {
            micBtn.style.backgroundColor = "#007bff";
            stopBtn.style.display = "none";
        };

        recognition.onerror = function (event) {
            console.error("Speech recognition error:", event.error);
            appendMessage("bot", "Sorry, I couldn't understand that.");
        };
    } else {
        micBtn.style.display = "none";
    }

    // --- Text-to-Speech ---
    function speakMessage(message) {
        if ("speechSynthesis" in window) {
            const utterance = new SpeechSynthesisUtterance(message);
            utterance.lang = selectedLanguage;
            speechSynthesis.speak(utterance);
            stopBtn.style.display = "block";
        }
    }

    stopBtn.addEventListener("click", function () {
        if (recognition) recognition.abort();
        speechSynthesis.cancel();
        stopBtn.style.display = "none";
    });
});